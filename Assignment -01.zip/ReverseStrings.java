package nirala;
import java.util.*;
public class ReverseStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str;
		System.out.println("Enter a string: ");
		str=sc.nextLine();
		
		Stack<Character> s=new Stack<>();
		
		for(int i=0;i<str.length();i++)
			s.push(str.charAt(i));
		
		System.out.println("The Reverse of string is: ");
		while(!s.empty()) {
			System.out.print(s.pop());
		}

	}

}
