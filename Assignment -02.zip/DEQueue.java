import java.util.*;

public class DEQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		char ch;
		ArrayDeque<Integer> ad=new ArrayDeque<>();
		do {
		System.out.println("1. for insert element from rear");
		System.out.println("2. for insert element from front");
		System.out.println("3. for delete element from rear");
		System.out.println("4. for delete element from front");
		System.out.println("5. for display ");
		System.out.println("6. for exit");
		int x,a,b;
		System.out.println("enter your choice: ");
		x=sc.nextInt();
		switch(x)
		{
		case 1:
			System.out.println("enter an element to be add(rear): ");
			a=sc.nextInt();
			ad.addLast(a);
			break;
		case 2:
			System.out.println("enter an element to be add(front): ");
			b=sc.nextInt();
			ad.addFirst(b);
			break;
		case 3:
			if(ad.isEmpty())
				System.out.println("Queue is empty!");
			else 
			ad.pollLast();
			break;
		case 4:
			if(ad.isEmpty())
				System.out.println("Queue is empty!");
			else 
			ad.pollFirst();
			break;
		case 5:
			Iterator itr=ad.iterator();
			while(itr.hasNext())
			{
				System.out.print(" "+itr.next());
			}
			break;
		case 6:
			System.exit(0);
			break;
			default:
				System.out.println("invalid input");
		}
		System.out.println("\nDo you want to continue[y/n]: ");
		ch=sc.next().charAt(0);
		}while(ch=='y');

	}

}
